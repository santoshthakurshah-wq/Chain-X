plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}
android {
    namespace="com.chainx.social"
    compileSdk=35
    defaultConfig {
        applicationId="com.chainx.social"
        minSdk=23
        targetSdk=35
        versionCode=1
        versionName="1.0"
    }
}
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:34.4.0"))
}
