package com.chainx.social
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()
