import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const android = FirebaseOptions(
    apiKey: 'AIzaSyB82Iz99H4dGG7GkSJrZPF0YbiSVfNx6ME',
    appId: '1:793288332601:android:7f2baec5610267324984e8',
    messagingSenderId: '793288332601',
    projectId: 'chain-x-c223c',
    databaseURL: 'https://chain-x-c223c-default-rtdb.firebaseio.com',
    storageBucket: 'chain-x-c223c.firebasestorage.app',
  );
}
