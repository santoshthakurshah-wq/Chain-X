import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.android);
  runApp(const ChainXApp());
}

class ChainXApp extends StatelessWidget {
  const ChainXApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Chain X',
    theme: ThemeData.dark(useMaterial3: true),
    home: const AuthPage(),
  );
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email=TextEditingController(), password=TextEditingController(), name=TextEditingController();
  bool signup=false, loading=false;

  Future<void> submit() async {
    if(email.text.trim().isEmpty || password.text.length<6 || (signup && name.text.trim().isEmpty)) return;
    setState(()=>loading=true);
    try {
      final a=FirebaseAuth.instance;
      if(signup) {
        final c=await a.createUserWithEmailAndPassword(email:email.text.trim(),password:password.text);
        await c.user!.updateDisplayName(name.text.trim());
        await FirebaseDatabase.instance.ref('users/${c.user!.uid}').set({
          'uid':c.user!.uid,'name':name.text.trim(),'email':email.text.trim(),
          'createdAt':ServerValue.timestamp,
        });
      } else {
        await a.signInWithEmailAndPassword(email:email.text.trim(),password:password.text);
      }
    } on FirebaseAuthException catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message??'Authentication failed')));
    } finally { if(mounted) setState(()=>loading=false); }
  }

  @override Widget build(BuildContext context) => StreamBuilder<User?>(
    stream:FirebaseAuth.instance.authStateChanges(),
    builder:(context,s)=>s.data!=null ? const HomePage() : Scaffold(
      body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Center(child:SingleChildScrollView(
        child:Column(children:[
          const Text('CX',style:TextStyle(fontSize:64,fontWeight:FontWeight.bold)),
          const Text('CHAIN X',style:TextStyle(fontSize:28,fontWeight:FontWeight.w700)),
          const SizedBox(height:25),
          SegmentedButton<bool>(
            segments:const [ButtonSegment(value:false,label:Text('Login')),ButtonSegment(value:true,label:Text('Sign Up'))],
            selected:{signup},onSelectionChanged:(x)=>setState(()=>signup=x.first)),
          const SizedBox(height:18),
          if(signup) TextField(controller:name,decoration:const InputDecoration(labelText:'Full name',border:OutlineInputBorder())),
          if(signup) const SizedBox(height:12),
          TextField(controller:email,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),
          const SizedBox(height:12),
          TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password (6+ characters)',border:OutlineInputBorder())),
          const SizedBox(height:20),
          SizedBox(width:double.infinity,height:50,child:FilledButton(onPressed:loading?null:submit,child:loading?const CircularProgressIndicator():Text(signup?'Create Account':'Log In'))),
        ]),
      ))))
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context) {
    final u=FirebaseAuth.instance.currentUser;
    return Scaffold(appBar:AppBar(title:const Text('Chain X'),actions:[IconButton(onPressed:()=>FirebaseAuth.instance.signOut(),icon:const Icon(Icons.logout))]),
      body:Center(child:Text('Welcome ${u?.displayName ?? u?.email ?? 'User'}!',style:const TextStyle(fontSize:22))));
  }
}
